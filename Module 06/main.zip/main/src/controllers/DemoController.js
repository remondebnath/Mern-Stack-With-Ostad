exports.demo1=(req,res)=>{
    res.send('Hello World 11')
}

exports.demo2=(req,res)=>{
    res.send('Hello World 22')
}



exports.demo3=(req,res)=>{
    res.send('Hello World 33')
}


exports.demo4=(req,res)=>{
    res.send('Hello World 44')
}