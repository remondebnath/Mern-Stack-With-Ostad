// Application Configuration
const express = require('express');
const app= new express();
const router= require('./src/routes/api')
const cookieParser = require('cookie-parser')


//
app.use(cookieParser())
app.use(express.json());
// Application Routes
app.use('/api',router);




module.exports=app;

